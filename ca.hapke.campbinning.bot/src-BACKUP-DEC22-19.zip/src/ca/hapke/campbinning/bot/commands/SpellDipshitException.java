package ca.hapke.campbinning.bot.commands;

/**
 * @author Nathan Hapke
 */
public class SpellDipshitException extends Exception {

	private static final long serialVersionUID = 6034023616066241599L;
	public static final String IM_A_DIPSHIT = "I'm a dipshit, and didn't pick a victim to cast a spell on!";
	public static final String YA_DIPSHIT = "Spells must be cast upon a victim, ya dipshit.";

}
