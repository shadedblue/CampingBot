package ca.hapke.campbinning.bot;

import java.util.List;

import ca.hapke.campbinning.bot.users.CampingUser;

/**
 * @author Nathan Hapke
 */
public abstract class CampingUtil {

	public static <T> T getRandom(List<T> l) {
		if (l == null || l.size() == 0)
			return null;

		int i = (int) (Math.random() * l.size());
		return l.get(i);
	}

	public static String prefixAt(String input) {
		if (input.charAt(0) != '@') {
			input = "@" + input;
		}
		return input;
	}

	public static String generateUsernameKey(String username) {
		if (username == null)
			return null;
		String result = removePrefixAt(username);
		return result.toLowerCase().trim();
	}

	public static String removePrefixAt(String input) {
		String result;
		if (input != null && input.length() > 0 && input.charAt(0) == '@') {
			result = input.substring(1);
		} else {
			result = input;
		}
		return result;
	}

	public static boolean isNonNull(String nickname) {
		return nickname != null && !CampingBot.STRING_NULL.equalsIgnoreCase(removePrefixAt(nickname));
	}

	public static String target(CampingUser cu) {
		if (cu == null)
			return "";
		String display = cu.getDisplayName();

		return CampingUtil.target(cu.getTelegramId(), display);
	}

	public static String target(Integer id, String display) {
		if (id == null)
			return display;
		else
			return "[" + display + "](tg://user?id=" + id + ")";
	}

}
