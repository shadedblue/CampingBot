package ca.hapke.campbinning.bot;

/**
 * @author Nathan Hapke
 */
public enum BotCommand {
	// AllFaces("allfaces"),
	// AllBalls("allballs"),
	// Stats("stats", true, false),
	// StatsEndOfWeek("stats-eow", true, false),
	Countdown("countdown", true, false),

	// Activator is the user who invokes /rant
	RantActivatorInitiation("rant", true, true, BotCommandIds.RANT | BotCommandIds.SET),
	// Ranter is the person who did the complaining
	RantRanterInitiation(null, true, true, BotCommandIds.RANT | BotCommandIds.REGULAR_CHAT | BotCommandIds.SET),
	RantActivatorComplete(null, true, true, BotCommandIds.RANT | BotCommandIds.FINISH),
	RantRanterComplete(null, true, true, BotCommandIds.RANT | BotCommandIds.REGULAR_CHAT | BotCommandIds.FINISH),

	// TODO add Rant events for Completion as non-rant?

	RantVote(null, true, true, BotCommandIds.RANT | BotCommandIds.USE),
	AllNicknames("allnicknames", false, false),
	SetNickname("setnickname", true, true, BotCommandIds.NICKNAME | BotCommandIds.SET),
	SetNicknameRejected(null, true, true, BotCommandIds.NICKNAME | BotCommandIds.FAILURE),
	Spell("spell", true, true, BotCommandIds.SPELL | BotCommandIds.USE),
	SpellDipshit(null, true, true, BotCommandIds.SPELL | BotCommandIds.FAILURE),
	Reload("reload", true, false),
	Test("test", true, false),
	// MBIYF("mbiyf", true),
	PleasureModel(null, true, true, BotCommandIds.PLEASURE),
	UiString(null, true, false),
	NicknameConversion(null, true, true, BotCommandIds.NICKNAME | BotCommandIds.USE),
	RegularChatUpdate(null, true, true, BotCommandIds.REGULAR_CHAT | BotCommandIds.TEXT),
	RegularChatReply(null, true, true, BotCommandIds.REGULAR_CHAT | BotCommandIds.REPLY),
	RegularChatEdit(null, true, true, BotCommandIds.REGULAR_CHAT | BotCommandIds.EDIT),
	RegularChatGif(null, true, true, BotCommandIds.REGULAR_CHAT | BotCommandIds.GIF),
	RegularChatSticker(null, true, true, BotCommandIds.REGULAR_CHAT | BotCommandIds.STICKER),
	RegularChatPhoto(null, true, true, BotCommandIds.REGULAR_CHAT | BotCommandIds.PIC),
	RegularChatVideo(null, true, true, BotCommandIds.REGULAR_CHAT | BotCommandIds.VID);

	private String command;
	private boolean forUi;
	private boolean forDb;
	public final long id;

	private BotCommand(String command, boolean forUi, boolean forDb) {
		this(command, forUi, forDb, 0);
	}

	/**
	 * @param command
	 *            The /command that the bot should respond to in the chat
	 * @param forUi
	 * @param forDb
	 * @param id
	 *            For logging purposes
	 */
	private BotCommand(String command, boolean forUi, boolean forDb, long id) {
		this.command = command;
		this.forUi = forUi;
		this.forDb = forDb;
		this.id = id;
	}

	public boolean isForUi() {
		return forUi;
	}

	public boolean isForDb() {
		return forDb;
	}

	public static BotCommand fromText(String msg) {
		if (msg == null)
			return null;
		for (BotCommand bc : values()) {
			if (msg.equalsIgnoreCase(bc.command))
				return bc;
		}
		return null;
	}
}
