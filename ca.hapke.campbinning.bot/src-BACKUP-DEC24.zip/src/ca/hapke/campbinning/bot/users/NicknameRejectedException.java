package ca.hapke.campbinning.bot.users;

/**
 * @author Nathan Hapke
 */
public class NicknameRejectedException extends Exception {

	private static final long serialVersionUID = -3018859494070428449L;
	public final String reason;

	public NicknameRejectedException(String reason) {
		this.reason = reason;
	}

}
