package ca.hapke.campbinning.bot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.AnswerInlineQuery;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.CallbackQuery;
import org.telegram.telegrambots.meta.api.objects.Message;
import org.telegram.telegrambots.meta.api.objects.MessageEntity;
import org.telegram.telegrambots.meta.api.objects.PhotoSize;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.api.objects.User;
import org.telegram.telegrambots.meta.api.objects.Video;
import org.telegram.telegrambots.meta.api.objects.games.Animation;
import org.telegram.telegrambots.meta.api.objects.inlinequery.ChosenInlineQuery;
import org.telegram.telegrambots.meta.api.objects.inlinequery.InlineQuery;
import org.telegram.telegrambots.meta.api.objects.inlinequery.inputmessagecontent.InputTextMessageContent;
import org.telegram.telegrambots.meta.api.objects.inlinequery.result.InlineQueryResult;
import org.telegram.telegrambots.meta.api.objects.inlinequery.result.InlineQueryResultArticle;
import org.telegram.telegrambots.meta.api.objects.stickers.Sticker;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;

import com.vdurmont.emoji.Emoji;

import ca.hapke.campbinning.bot.channels.CampingChat;
import ca.hapke.campbinning.bot.channels.CampingChatManager;
import ca.hapke.campbinning.bot.commands.CountdownGenerator;
import ca.hapke.campbinning.bot.commands.MbiyfCommand;
import ca.hapke.campbinning.bot.commands.PleasureModelCommand;
import ca.hapke.campbinning.bot.commands.RantManager;
import ca.hapke.campbinning.bot.commands.SpellDipshitException;
import ca.hapke.campbinning.bot.commands.SpellGenerator;
import ca.hapke.campbinning.bot.commands.TextCommand;
import ca.hapke.campbinning.bot.commands.TextCommandResult;
import ca.hapke.campbinning.bot.interval.CampingIntervalThread;
import ca.hapke.campbinning.bot.log.DatabaseConsumer;
import ca.hapke.campbinning.bot.log.EventItem;
import ca.hapke.campbinning.bot.log.EventLogger;
import ca.hapke.campbinning.bot.users.CampingUser;
import ca.hapke.campbinning.bot.users.CampingUserMonitor;
import ca.hapke.campbinning.bot.users.NicknameRejectedException;

/**
 * @author Nathan Hapke
 */
public class CampingBot extends TelegramLongPollingBot {

	public static final String UNKNOWN_TARGET = "unknown target";
	private static final String INLINE_NICKS = "nicks";
	private static final String INLINE_SPELL = "spell";
	private static final String INLINE_DELIMITER = ":";
	public static final String STRING_NULL = "null";
	private static final String BOT_COMMAND = "bot_command";
	private static final String MARKDOWN = "Markdown";
	public static final String TEXT_MENTION = "text_mention";
	public static final String MENTION = "mention";
	private User me;
	private CampingUser meCamping;
	private Resources res = new Resources();
	private EventLogger eventLogger = EventLogger.getInstance();
	private CampingChatManager chatManager = CampingChatManager.getInstance();
	private CampingUserMonitor userMonitor = CampingUserMonitor.getInstance();
	// private StatsGenerator stats = new StatsGenerator(res, userMonitor);
	// private SundayStatsReset sundayStats = new SundayStatsReset(this, stats);
	private CampingSystem system = CampingSystem.getInstance();
	private RantManager rants = new RantManager();
	private SpellGenerator spellGen = new SpellGenerator();
	private MbiyfCommand ballsCommand = new MbiyfCommand(this, res);
	private TextCommand[] textCommands = new TextCommand[] { ballsCommand, new PleasureModelCommand(this) };
	private CountdownGenerator countdownGen = new CountdownGenerator(res);
	private DatabaseConsumer databaseConsumer = new DatabaseConsumer(system, eventLogger);

	private CampingXmlSerializer serializer = new CampingXmlSerializer(system,
			// sundayStats,
			spellGen, countdownGen, userMonitor);

	public CampingBot() {
		res.loadAllEmoji();
		serializer.load();

		CampingIntervalThread.put(serializer);
		CampingIntervalThread.put(databaseConsumer);
		// CampingIntervalThread.put(userMonitor);
		// CampingIntervalThread.put(sundayStats);
		CampingIntervalThread.put(ballsCommand);
		CampingIntervalThread.put(rants);
	}

	@Override
	public void onUpdateReceived(Update update) {
		EventItem event = null;
		Integer eventTime = null;

		// res.getCampbinningStickerPack(this);
		if (me == null) {
			try {
				me = getMe();
				meCamping = userMonitor.monitor(me);
			} catch (TelegramApiException e) {
				e.printStackTrace();
			}
		}

		if (update.hasCallbackQuery()) {
			CallbackQuery callbackQuery = update.getCallbackQuery();
			event = rants.reactToCallback(callbackQuery);
		}
		if (update.hasInlineQuery()) {
			// provide the option to cast spells

			InlineQuery inlineQuery = update.getInlineQuery();
			if (inlineQuery.hasQuery()) {

				List<InlineQueryResult> results = new ArrayList<>();
				int updateId = update.getUpdateId();

				String input = inlineQuery.getQuery();
				String[] words = input.split(" ");

				if (words.length >= 1) {
					String outputSpell;
					CampingUser targetUser = userMonitor.getUser(words[0]);
					String targetFirst;
					if (targetUser != null) {
						outputSpell = spellGen.cast(targetUser.target());
						targetFirst = targetUser.getFirstname();
					} else {
						outputSpell = SpellDipshitException.IM_A_DIPSHIT;
						targetFirst = UNKNOWN_TARGET;
					}

					int targetId = -1;

					if (targetUser != null) {
						targetId = targetUser.getTelegramId();
					}
					AnswerInlineQuery answerSpell = new AnswerInlineQuery();
					answerSpell.setInlineQueryId(inlineQuery.getId());

					InputTextMessageContent mcSpell = new InputTextMessageContent();
					mcSpell.setDisableWebPagePreview(true);
					mcSpell.setMessageText(outputSpell);
					mcSpell.setParseMode(MARKDOWN);

					InlineQueryResultArticle articleSpell = new InlineQueryResultArticle();
					articleSpell.setTitle("spell on " + targetFirst);
					articleSpell.setId(createQueryId(INLINE_SPELL, updateId, targetId));
					articleSpell.setInputMessageContent(mcSpell);
					results.add(articleSpell);
				}

				// provide the option to change nicknames

				String[] out = new String[words.length];
				String converted = null;
				List<Integer> convertedIds = new ArrayList<>();
				for (int i = 0; i < words.length; i++) {
					String word = words[i];
					String newWord = word;
					if (word.length() > 0 && word.charAt(0) == '@') {
						CampingUser cu = userMonitor.getUser(word);
						if (cu != null) {
							newWord = cu.target();
							String firstOrUser = cu.getFirstOrUserName();
							if (converted == null) {
								converted = firstOrUser;
							} else {
								converted = converted + ", " + firstOrUser;
							}
							convertedIds.add(cu.getTelegramId());
						}

					}
					out[i] = newWord;
				}
				String output = String.join(" ", out);

				AnswerInlineQuery answer = new AnswerInlineQuery();
				answer.setInlineQueryId(inlineQuery.getId());

				InputTextMessageContent mc = new InputTextMessageContent();
				mc.setDisableWebPagePreview(true);
				mc.setMessageText(output);
				mc.setParseMode(MARKDOWN);

				InlineQueryResultArticle articleUsernameConversion = new InlineQueryResultArticle();
				if (converted == null)
					converted = "None";
				articleUsernameConversion.setTitle("@usernames converted: " + converted);
				articleUsernameConversion.setId(createQueryId(INLINE_NICKS, updateId, convertedIds));
				articleUsernameConversion.setInputMessageContent(mc);

				results.add(articleUsernameConversion);

				answer.setResults(results);

				try {
					execute(answer);
				} catch (TelegramApiException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		if (update.hasChosenInlineQuery()) {
			// User chose an inline spell or @username conversion

			ChosenInlineQuery inlineChosen = update.getChosenInlineQuery();
			String[] words = inlineChosen.getResultId().split(INLINE_DELIMITER);
			Integer inlineMessageId = null;

			User from = inlineChosen.getFrom();
			CampingUser campingFromUser = userMonitor.getUser(from);
			if (words.length >= 1) {
				if (INLINE_SPELL.equalsIgnoreCase(words[0]) && words.length >= 3) {
					int targetUserId = Integer.parseInt(words[2]);
					if (targetUserId > 0) {
						CampingUser targetUser = userMonitor.getUser(targetUserId);
						countSpellActivation(campingFromUser, null, targetUser);
						String result = words.length >= 2 ? words[2] : null;
						event = new EventItem(BotCommand.Spell, campingFromUser, null, null, inlineMessageId, result,
								targetUser.getCampingId());
					}
				} else if (INLINE_NICKS.equalsIgnoreCase(words[0]) && words.length >= 2) {
					String[] targets = new String[words.length - 2];
					for (int i = 0; i < targets.length; i++) {
						CampingUser target = userMonitor.getUser(Integer.parseInt(words[i + 2]));
						targets[i] = target.getFirstOrUserName();
					}

					String rest = String.join(", ", targets);
					event = new EventItem(BotCommand.NicknameConversion, campingFromUser, null, null, inlineMessageId,
							rest, targets.length);
				}

			}
		}

		Message message = update.getMessage();
		Integer telegramId;
		if (update.hasEditedMessage()) {
			message = update.getEditedMessage();
			telegramId = message.getMessageId();
			List<MessageEntity> entities = message.getEntities();

			CampingUser campingFromUser = aggressiveMonitor(message.getFrom(), entities);

			Long chatId = message.getChatId();
			CampingChat chat = chatManager.get(chatId, this);

			String afterText = message.getText();
			eventTime = message.getEditDate();

			event = new EventItem(BotCommand.RegularChatEdit, campingFromUser, eventTime, chat, telegramId, afterText,
					null);
		}

		if (message != null) {
			User fromUser = message.getFrom();
			List<MessageEntity> entities = message.getEntities();

			CampingUser campingFromUser = aggressiveMonitor(fromUser, entities);
			CampingChat chat = null;
			telegramId = message.getMessageId();
			Long chatId = message.getChatId();
			if (chatId != null)
				chat = chatManager.get(chatId, this);

			BotCommand command = null;
			String rest = "";
			Object extraData = null;
			eventTime = message.getDate();

			if (message.hasAnimation()) {
				// responds to GIFs
				command = BotCommand.RegularChatGif;
				Animation animation = message.getAnimation();
				rest = animation.getFileId();
				extraData = animation.getDuration();
			} else if (message.hasPhoto()) {
				command = BotCommand.RegularChatPhoto;
				try {
					List<PhotoSize> photos = message.getPhoto();
					Map<String, PhotoSize> photosLargest = new HashMap<>(photos.size());

					for (PhotoSize photo : photos) {
						String key = photo.getFileId();
						PhotoSize currentLargest = photosLargest.get(key);
						if (currentLargest == null || photo.getHeight() > currentLargest.getHeight())
							photosLargest.put(key, photo);
					}
					for (PhotoSize photo : photosLargest.values()) {
						if (rest.length() > 0)
							rest = rest + "\n";
						rest = rest + photo.toString();
					}
					extraData = photosLargest.size();
				} catch (Exception e) {
				}
			} else if (message.hasVideo()) {
				command = BotCommand.RegularChatVideo;
				Video video = message.getVideo();
				rest = video.toString();
				extraData = video.getDuration();
			} else if (message.hasSticker()) {
				command = BotCommand.RegularChatSticker;
				Sticker stick = message.getSticker();
				rest = stick.getEmoji();
				extraData = stick.getSetName();
			}

			if (update.hasMessage() && message.hasText()) {
				String originalMsg = message.getText();
				String prefix = campingFromUser.target();

				if (command == null) {
					command = findCommand(update, me);
				}

				try {
					if (command == null) {
						String msg = originalMsg.toLowerCase().trim();

						// handles mbiyf and pleasure model
						TextCommandResult result = null;
						for (TextCommand textCommand : textCommands) {
							if (textCommand.isMatch(msg, entities)) {
								result = textCommand.textCommand(campingFromUser, entities, chatId);
								if (result != null)
									break;
							}
						}

						if (result != null) {
							rest = result.msg;
							if (result.shouldSendMsg)
								sendMsg(chatId, rest);
							command = result.cmd;
						}

						if (command == null) {
							// figure out what type of message it is... ie:
							// regular message/edit/delete

							command = BotCommand.RegularChatUpdate;
							rest = originalMsg;

							Message replyTo = message.getReplyToMessage();
							if (replyTo != null) {
								command = BotCommand.RegularChatReply;
								extraData = replyTo.getMessageId();
							}

						}
					} else {
						switch (command) {
						case NicknameConversion:
						case MBIYF:
						case MBIYFDipshit:
						case RegularChatUpdate:
						case RegularChatReply:
						case PleasureModel:
							// NOOP
							break;
						case RantRanterComplete:
						case RantVote:
						case RantActivatorComplete:
						case RantRanterInitiation:
							// case StatsEndOfWeek:
							// NOOP : internal events, not responses
							break;

						case AllBalls:
							sendMsg(chatId, res.listBalls());
							break;
						case AllFaces:
							sendMsg(chatId, res.listFaces());
							break;
						// case Stats:
						// sendMsg(chatId, stats.statsCommand(chatId));
						// break;

						case SpellDipshit:
							// NOOP, but must be before Spell
							break;
						case Spell:
							try {
								rest = spellCommand(campingFromUser, chat, entities);

							} catch (SpellDipshitException e) {
								command = BotCommand.SpellDipshit;
								rest = prefix + " " + SpellDipshitException.YA_DIPSHIT;
							}
							sendMsg(chatId, rest);
							break;

						case RantActivatorInitiation:
							rest = rants.startRant(this, message, chatId, campingFromUser);
							break;

						case Countdown:
							String countdown = countdownGen.countdownCommand(userMonitor, chatId);
							sendMsg(chatId, countdown);
							rest = countdown;
							break;

						case AllNicknames:
							rest = allNicknamesCommand();
							sendMsg(chatId, rest);
							break;
						case SetNickname:
							try {
								rest = setNicknameCommand(originalMsg, chatId, campingFromUser, entities);
							} catch (NicknameRejectedException e) {
								command = BotCommand.SetNicknameRejected;
								rest = e.reason;
							}
							sendMsg(chatId, prefix + " " + rest);
							break;

						case SetNicknameRejected:
							// must be after SetNickname:
							break;
						case Reload:
							rest = reloadCommand(fromUser);
							sendMsg(chatId, prefix + rest);
							break;
						case Test:
							rest = testCommand(fromUser, chatId);
							break;
						case UiString:
							break;
						// case RegularChatAnimation:
						case RegularChatGif:
						case RegularChatPhoto:
						case RegularChatEdit:
						case RegularChatVideo:
						case RegularChatSticker:
							break;
						}

					}

				} catch (TelegramApiException e) {
					event = new EventItem(command, campingFromUser, eventTime, chat, telegramId,
							"Exception: " + e.getMessage(), null);

				}
			}
			if (event == null && command != null)
				event = new EventItem(command, campingFromUser, eventTime, chat, telegramId, rest, extraData);
		}
		if (event != null)
			eventLogger.add(event);

	}

	public CampingUser aggressiveMonitor(User fromUser, List<MessageEntity> entities) {
		CampingUser campingFromUser = null;
		if (fromUser != null) {
			campingFromUser = userMonitor.monitor(fromUser);
		}
		if (entities != null) {
			for (MessageEntity msgEnt : entities) {
				userMonitor.monitor(msgEnt);
			}
		}
		return campingFromUser;
	}

	private String createQueryId(String command, int updateId, List<Integer> convertedIds) {
		int[] inputs = new int[convertedIds.size() + 1];
		inputs[0] = updateId;
		for (int i = 0; i < convertedIds.size(); i++) {
			inputs[i + 1] = convertedIds.get(i);
		}
		return createQueryId(command, inputs);
	}

	private String createQueryId(String command, int... ids) {
		String[] inputs = new String[ids.length + 1];
		inputs[0] = command;
		for (int i = 0; i < ids.length; i++) {
			inputs[i + 1] = Integer.toString(ids[i]);
		}

		return String.join(INLINE_DELIMITER, inputs);
	}

	private String spellCommand(CampingUser campingFromUser, CampingChat chat, List<MessageEntity> entities)
			throws SpellDipshitException {
		CampingUser targetUser = findTarget(entities);
		if (targetUser == null) {
			throw new SpellDipshitException();
		}

		String out = spellGen.cast(targetUser.target());
		countSpellActivation(campingFromUser, chat, targetUser);
		return out;
	}

	public void countSpellActivation(CampingUser fromUser, CampingChat chat, CampingUser targetUser) {
		fromUser.increment(BotCommand.Spell);
		targetUser.victimize(BotCommand.Spell);
	}

	public CampingUser findTarget(List<MessageEntity> entities) {
		CampingUser targetUser = null;
		int minOffset = -1;
		if (entities == null)
			return null;
		for (MessageEntity msgEnt : entities) {
			String type = msgEnt.getType();
			int offset = msgEnt.getOffset();
			if (minOffset == -1 || offset < minOffset) {
				if (MENTION.equalsIgnoreCase(type)) {
					// usernamed victim: the text is their
					// @username
					targetUser = userMonitor.monitor(msgEnt);
				} else if (TEXT_MENTION.equalsIgnoreCase(type)) {
					// non-usernamed victim: we get the User
					// struct
					targetUser = userMonitor.getUser(msgEnt.getUser());
				} else {
					continue;
				}
			}
		}
		return targetUser;
	}

	public String reloadCommand(User fromUser) {
		String result;
		if (system.isAdmin(fromUser)) {
			res.loadAllEmoji();
			serializer.load();
			// spellGen.loadStuff();
			result = " Done!";
		} else {
			result = " Access Denied!";
		}
		return result;
	}

	public String testCommand(User fromUser, Long chatId) {
		return "";
	}

	public String setNicknameCommand(String originalMsg, Long chatId, CampingUser campingFromUser,
			List<MessageEntity> entities) throws NicknameRejectedException {
		int targetOffset = originalMsg.indexOf(" ") + 1;
		int nickOffset = originalMsg.indexOf(" ", targetOffset) + 1;
		String result = "Invalid syntax";
		if (targetOffset > 0 && nickOffset > targetOffset + 1) {
			String newNickname = originalMsg.substring(nickOffset);
			MessageEntity targeting = null;

			for (MessageEntity msgEnt : entities) {
				int offset = msgEnt.getOffset();
				String type = msgEnt.getType();
				if (offset == targetOffset && (MENTION.equalsIgnoreCase(type) || TEXT_MENTION.equalsIgnoreCase(type))) {
					targeting = msgEnt;
				}
			}
			if (targeting != null) {
				CampingUser targetUser = userMonitor.getUser(targeting);

				if (targetUser != null) {
					if (targetUser == campingFromUser) {
						throw new NicknameRejectedException("#1 rule of nicknames: you can't give yourself a nickname");
					} else {
						targetUser.setNickname(newNickname);

						result = targetUser.getFirstOrUserName() + "'s nickname changed to: " + targetUser.target();
					}
				} else {
					throw new NicknameRejectedException("Could not find user in system.");
				}
			}
		}
		return result;
	}

	public String allNicknamesCommand() {
		StringBuilder sb = new StringBuilder();
		for (CampingUser u : userMonitor.getUsers()) {
			String first = u.getFirstname();
			String nick = u.getNickname();
			if (CampingUtil.notEmptyOrNull(nick) && CampingUtil.notEmptyOrNull(first)) {
				sb.append("*");
				sb.append(first);
				sb.append("*: ");
				sb.append(nick);
				sb.append("\n");
			}

		}
		String out = sb.toString();
		return out;
	}

	private static BotCommand findCommand(Update update, User me) {
		Message message = update.getMessage();
		List<MessageEntity> entities = message.getEntities();
		if (entities != null) {
			for (MessageEntity msgEnt : entities) {
				String type = msgEnt.getType();
				if (BOT_COMMAND.equalsIgnoreCase(type) && msgEnt.getOffset() == 0) {
					boolean targetsMe;
					String msg = msgEnt.getText();
					String command = msg;
					int start = msg.indexOf('/');
					int at = msg.indexOf('@');
					int length = msg.length();
					if (at > 0) {
						command = msg.substring(start + 1, at);
						String target = msg.substring(at + 1, length);
						targetsMe = matchOne(target, me.getFirstName(), me.getUserName(), me.getLastName());
					} else {
						command = msg.substring(start + 1);
						targetsMe = true;
					}

					if (targetsMe) {
						return BotCommand.fromText(command);
					}
				}
			}
		}

		return null;
	}

	private static boolean matchOne(String target, String... accepts) {
		for (int i = 0; i < accepts.length; i++) {
			String s = accepts[i];
			if (s != null && s.length() > 0 && s.equalsIgnoreCase(target))
				return true;
		}
		return false;
	}

	public Message sendMsg(Long chatId, String msg) {
		SendMessage send = new SendMessage(chatId, msg);
		send.setParseMode(MARKDOWN);
		try {
			return execute(send);
		} catch (TelegramApiException e) {
			e.printStackTrace();
		}
		return null;
	}

	public Message sendReply(Long chatId, Message message, String msg) {
		SendMessage send = new SendMessage(chatId, msg);
		send.setReplyToMessageId(message.getMessageId());
		send.setParseMode(MARKDOWN);
		try {
			return execute(send);
		} catch (TelegramApiException e) {
			e.printStackTrace();
		}
		return null;
	}

	public Set<Emoji> findMatches(String msg) {
		Set<Emoji> emojis = null;

		for (Emoji e : res.respondTo) {
			if (e != null && msg != null && msg.contains(e.getUnicode())) {
				if (emojis == null)
					emojis = new HashSet<>();
				emojis.add(e);
			}
		}

		return emojis;
	}

	@Override
	public String getBotToken() {
		return system.getToken();
	}

	@Override
	public String getBotUsername() {
		return system.getBotUsername();
	}

	public CampingUser getMeCamping() {
		return meCamping;
	}

}