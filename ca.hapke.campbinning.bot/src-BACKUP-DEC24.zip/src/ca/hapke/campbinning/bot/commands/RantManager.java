package ca.hapke.campbinning.bot.commands;

import java.util.HashMap;
import java.util.Map;

import org.telegram.telegrambots.meta.api.objects.CallbackQuery;
import org.telegram.telegrambots.meta.api.objects.Message;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;

import ca.hapke.campbinning.bot.BotCommand;
import ca.hapke.campbinning.bot.CampingBot;
import ca.hapke.campbinning.bot.interval.IntervalBySeconds;
import ca.hapke.campbinning.bot.log.EventItem;
import ca.hapke.campbinning.bot.users.CampingUser;
import ca.hapke.campbinning.bot.users.CampingUserMonitor;
import ca.hapke.campbinning.bot.users.RantTracker;
import ca.odell.glazedlists.BasicEventList;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.GlazedLists;

/**
 * @author Nathan Hapke
 */
public class RantManager implements IntervalBySeconds {
	private Map<Integer, RantTracker> rantingAtMessages = new HashMap<Integer, RantTracker>();
	private Map<Integer, RantTracker> rantBanners = new HashMap<Integer, RantTracker>();

	private EventList<RantTracker> rantsInProgress = GlazedLists.threadSafeList(new BasicEventList<RantTracker>());

	@Override
	public int getSeconds() {
		return 60;
	}

	@Override
	public void doWork() {
		for (int i = 0; i < rantsInProgress.size(); i++) {
			RantTracker r = rantsInProgress.get(i);

			long now = System.currentTimeMillis();
			if (now > r.getCompletionTime() || r.isCompleted()) {
				r.complete();
				float score = r.getScore();
				r.getRanter().completeRant(score);
				r.getActivater().increment(BotCommand.RantActivatorComplete);
				rantsInProgress.remove(r);
				continue;
			} else {
				r.update();
			}
		}
	}

	public String startRant(CampingBot bot, Message message, Long chatId, CampingUser activater)
			throws TelegramApiException {
		String rest;
		Integer messageId = message.getMessageId();
		if (rantingAtMessages.containsKey(messageId)) {
			rest = "Rant already being voted on";
			bot.sendReply(chatId, message, rest);
		} else {
			Message replyToRant = message.getReplyToMessage();
			if (replyToRant != null) {
				CampingUserMonitor uM = CampingUserMonitor.getInstance();
				CampingUser ranter = uM.monitor(replyToRant.getFrom());

				RantTracker rant = new RantTracker(bot, ranter, activater, chatId, message, replyToRant);

				rantsInProgress.add(rant);
				rantingAtMessages.put(messageId, rant);
				rantBanners.put(rant.getBanner().getMessageId(), rant);
				rest = replyToRant.getText();
				ranter.increment(BotCommand.RantActivatorInitiation);
			} else {
				bot.sendReply(chatId, message, "Reply to the rant you would like to vote on!");
				rest = "No rant provided";
			}
		}
		return rest;
	}

	public EventItem reactToCallback(CallbackQuery callbackQuery) {
		Integer callbackMessageId = callbackQuery.getMessage().getMessageId();
		RantTracker rant = rantBanners.get(callbackMessageId);

		try {
			if (rant != null) {
				EventItem react = rant.react(callbackQuery);
				return react;
			}
		} catch (TelegramApiException e) {
		}
		return null;
	}

	@Override
	public boolean shouldRun() {
		boolean result = false;
		if (rantsInProgress.getReadWriteLock().readLock().tryLock()) {
			try {
				result = rantsInProgress.size() > 0;
			} finally {
				rantsInProgress.getReadWriteLock().readLock().unlock();
			}
		}
		return result;
	}
}
